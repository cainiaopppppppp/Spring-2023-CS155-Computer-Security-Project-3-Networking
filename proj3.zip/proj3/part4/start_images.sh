#!/bin/bash

docker-compose up --detach dns
docker-compose up --detach http
